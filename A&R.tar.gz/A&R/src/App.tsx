import { useEffect, useState } from 'react';
import { Route, Routes, useLocation } from 'react-router-dom';

import Loader from './common/Loader/index';
import PageTitle from './components/PageTitle';
import FormElements from './pages/Form/FormElements';
import FormLayout from './pages/Form/FormLayout';
import Settings from './pages/Settings';
import Tables from './pages/Tables';
import HostsPage from './pages/Hosts';
import HostGroupPage from './pages/HostGroupPage';
import NewHost from './pages/NewHost';
import NewHostGroup from './pages/NewHostGroup';
import SitesPage from './pages/SitesPage';
import NewSite from './pages/NewSite';
import CommandViews from './pages/CommandViews';
import NewCommand from './pages/NewCommand';
import AllReports from './pages/AllReports';
import NewReport from './pages/NewReport';
import CommandGroupView from './pages/CommandGroupView';
import NewCommandGroup from './pages/NewCommandGroup';

function App() {
  const [loading, setLoading] = useState<boolean>(true);
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  useEffect(() => {
    setTimeout(() => setLoading(false), 1000);
  }, []);

  return loading ? (
    <Loader />
  ) : (
    <>
      <Routes>
        <Route
          path="/forms/form-elements"
          element={
            <>
              <PageTitle title="Form Elements | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <FormElements />
            </>
          }
        />
        <Route
          path="/forms/form-layout"
          element={
            <>
              <PageTitle title="Form Layout | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <FormLayout />
            </>
          }
        />

        <Route
          path="/hosts/hosts"
          element={
            <>
              <PageTitle title="Hosts | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <HostsPage />
            </>
          }
        />
        <Route
          path="/hosts/groups"
          element={
            <>
              <PageTitle title="Host Groups | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <HostGroupPage />
            </>
          }
        />
        <Route
          path="/hosts/hosts/new"
          element={
            <>
              <PageTitle title="New Host | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <NewHost />
            </>
          }
        />
        <Route
          path="/hosts/groups/new"
          element={
            <>
              <PageTitle title="New HostGroup | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <NewHostGroup />
            </>
          }
        />

        <Route
          path="/hosts/site/new"
          element={
            <>
              <PageTitle title="New HostGroup | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <NewSite />
            </>
          }
        />
        <Route
          path="/hosts/site"
          element={
            <>
              <PageTitle title="New HostGroup | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <SitesPage />
            </>
          }
        />
        <Route
          path="/commands/new"
          element={
            <>
              <PageTitle title="Tables | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <NewCommand />
            </>
          }
        />

        <Route
          path="/commands/all"
          element={
            <>
              <PageTitle title="Tables | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <CommandViews />
            </>
          }
        />
        <Route
          path="/commands/groups"
          element={
            <>
              <PageTitle title="Tables | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <CommandGroupView />
            </>
          }
        />
        <Route
          path="/commands/groups/new"
          element={
            <>
              <PageTitle title="Command Groups | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <NewCommandGroup />
            </>
          }
        />
        <Route
          path="/reports/new"
          element={
            <>
              <PageTitle title="Tables | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <NewReport />
            </>
          }
        />

        <Route
          path="/reports/all"
          element={
            <>
              <PageTitle title="Tables | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <AllReports />
            </>
          }
        />

        <Route
          path="/tables"
          element={
            <>
              <PageTitle title="Tables | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <Tables />
            </>
          }
        />
        <Route
          path="/settings"
          element={
            <>
              <PageTitle title="Settings | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <Settings />
            </>
          }
        />
      </Routes>
    </>
  );
}

export default App;
