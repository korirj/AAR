import Breadcrumb from '../components/Breadcrumbs/Breadcrumb';
import ReportsTable from '../components/Tables/ReportsTable';
import DefaultLayout from '../layout/DefaultLayout';
import { Link } from 'react-router-dom';

const AllReports = () => {
  return (
    <DefaultLayout>
      <Breadcrumb pageName="Reports" />
      <div className="p-2 md:p-4 xl:p-4">
          <div className="mb-1.5 flex flex-wrap gap-2 xl:gap-10">
            <Link
              to="new"
              className="inline-flex items-center justify-center rounded-md bg-primary py-2 px-6 text-center font-medium text-white hover:bg-opacity-90 lg:px-5 xl:px-8"
            >
              New Report
            </Link>
          </div>
      </div>
      <div className="flex flex-col gap-10">
        <ReportsTable />
      </div>
    </DefaultLayout>
  );
};

export default AllReports;
