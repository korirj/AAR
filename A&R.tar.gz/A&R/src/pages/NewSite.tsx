import Breadcrumb from '../components/Breadcrumbs/Breadcrumb';
import DefaultLayout from '../layout/DefaultLayout';
import { useState } from 'react';

const NewSite = () => {
  const [enabled, setEnabled] = useState<boolean>(false);

  return (
    <DefaultLayout>
      <Breadcrumb pageName="New Site" />

      <div className="grid grid-cols-1 gap-9 sm:grid-cols-1 max-w-2xl mx-auto">
        <div className="flex flex-col gap-9">
          {/* <!-- Contact Form --> */}
          <div className="rounded-sm border  border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
            <div className="border-b  border-stroke py-4 px-6.5 dark:border-strokedark">
              <h3 className="font-medium  text-black dark:text-white">
                Site Details
              </h3>
            </div>
            <form action="#">
              <div className="p-6.5">
                <div className="mb-4.5">
                  <label className="mb-2.5 block text-black dark:text-white">
                    Site Name <span className="text-meta-1">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="Site name"
                    className="w-full rounded border-[1.5px] border-stroke bg-transparent py-3 px-5 text-black outline-none transition focus:border-primary active:border-primary disabled:cursor-default disabled:bg-whiter dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
                  />
                </div>

                <div className="mb-4.5">
                  <div>
                    <label
                      htmlFor="toggle1"
                      className="flex cursor-pointer select-none items-center"
                    >
                      {' '}
                      <div className="relative">
                        <input
                          type="checkbox"
                          id="toggle1"
                          className="sr-only"
                          onChange={() => {
                            setEnabled(!enabled);
                          }}
                        />
                        <div className="block h-8 w-14 rounded-full bg-meta-9 dark:bg-[#5A616B]"></div>

                        <div
                          className={`absolute left-1 top-1 h-6 w-6 rounded-full bg-white transition ${
                            enabled &&
                            '!right-1 !translate-x-full !bg-primary dark:!bg-white'
                          }`}
                        ></div>
                      </div>
                      {enabled ? (
                        <span className="px-2 text-green-500">Enabled</span>
                      ) : (
                        <span className="px-2 text-red-500">Disabled</span>
                      )}
                    </label>
                  </div>
                </div>

                <button className="flex w-full justify-center rounded bg-primary p-3 font-medium text-gray hover:bg-opacity-90">
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </DefaultLayout>
  );
};

export default NewSite;
