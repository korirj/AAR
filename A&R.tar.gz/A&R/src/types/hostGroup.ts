export type HostGroup = {
  id: number;
  name: string;
  username: string;
  password: string;
  site: string;
  status: string;
};
