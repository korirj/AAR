
export type Reports = {
  id: number;
  commandMap: Array<Object>;
  description: string;
  name: string;
  status: string;
};
