export type Site = {
  id: number;
  name: string;
  status: string;
  hostGroups: number;
};
