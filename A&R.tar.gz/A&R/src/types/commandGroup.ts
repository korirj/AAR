export type CommandGroup = {
  id: number;
  name: string;
  status: string;
  commands: Array<number>;
  description: string;
};
