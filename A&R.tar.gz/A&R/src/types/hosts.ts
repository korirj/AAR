export type Host = {
  id: number;
  hostname: string;
  hostGroup: string;
  hostIP: string;
  status: string;
};
