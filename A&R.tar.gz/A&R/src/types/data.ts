import { Command } from './command';
import { HostGroup } from './hostGroup';
import { Host } from './hosts';
import { Site } from './site';
import { Reports } from './reports';
import { CommandGroup } from './commandGroup';
const siteData: Site[] = [
  { id: 1, name: 'Site Name', status: 'active', hostGroups: 3 },
  { id: 2, name: 'site 2 Name', status: 'inactive', hostGroups: 3 },
  { id: 3, name: 'Site 3 Name', status: 'Inactive', hostGroups: 3 },
];
const groupData: HostGroup[] = [
  {
    id: 1,
    name: 'Group Name',
    username: 'Username',
    password: 'Password',
    site: 'production',
    status: 'active',
  },
  {
    id: 2,
    name: 'Group Name',
    username: 'Username',
    password: 'Password',
    site: 'production',
    status: 'active',
  },
  {
    id: 3,
    name: 'Group Name',
    username: 'Username',
    password: 'Password',
    site: 'production',
    status: 'active',
  },
];

const hostData: Host[] = [
  {
    id: 1,
    hostname: 'Hostname',
    hostGroup: 'Free',
    hostIP: '89.207.132.170',
    status: 'active',
  },
  {
    id: 2,
    hostname: 'Hostname',
    hostGroup: 'Free',
    hostIP: '89.207.132.170',
    status: 'active',
  },
  {
    id: 3,
    hostname: 'Hostname',
    hostGroup: 'Free',
    hostIP: '89.207.132.170',
    status: 'active',
  },
];

const commands: Command[] = [
  {
    id: 1,
    name: 'Check hostname',
    command: 'hostname',
    description: 'Command to check hostname',
    status: 'active',
  },
  {
    id: 2,
    name: 'Check ip address',
    command: 'hostname -i',
    description: 'Command to check ip address',
    status: 'active',
  },
  {
    id: 3,
    name: 'Check OS version',
    command: 'cat /etc/os-release',
    description: 'Command to check OS version',
    status: 'active',
  },
  {
    id: 4,
    name: 'Check top processes',
    command: 'hostname -i',
    description: 'Command to top processes',
    status: 'inactive',
  },
];

const commandGroupData: CommandGroup[] = [
  {
    id: 1,
    name: 'Check Something Unique',
    status: 'active',
    commands: [1, 2, 3],
    description: 'Check something unique',
  },
  {
    id: 2,
    name: 'Check Another Unique',
    status: 'active',
    commands: [1, 2, 3],
    description: 'Check something unique',
  },
];

const reportData: Reports[] = [
  {
    id: 1,
    commandMap: [
      {
        1: [1, 2, 3],
      },
      { 2: [2, 3] },
      { 3: [3] },
    ],
    description: 'Report for testing',
    name: 'NE REPORT',
    status: 'active',
  },
  {
    id: 2,
    commandMap: [
      {
        1: [1, 2, 3],
      },
      { 4: [2, 3] },
      { 3: [3] },
    ],
    description: 'Report for testing',
    name: 'DB REPORT',
    status: 'active',
  },
];

export {
  groupData,
  hostData,
  siteData,
  commands,
  commandGroupData,
  reportData,
};
