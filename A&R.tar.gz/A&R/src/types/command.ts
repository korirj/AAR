export type Command = {
  id: number;
  name: string;
  status: string;
  command: string;
  description: string;

};
