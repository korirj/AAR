const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const db = require('./db');
const ip = require('ip');
const Response = require('./util/response');
const logger = require('./util/logger');
const  httpStatus  = require('./query/httpStatus');
const { errorHandler } = require('./util/error');

const reportRoute = require('./routes/reportRoute');
const hostRoute = require('./routes/hostRoute');
const commandRoute = require('./routes/commandRoute');

dotenv.config();
const PORT = process.env.SERVER_PORT || 3000;
const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json());

app.use('/api/reports', reportRoute);
app.use('/api/hosts', hostRoute);
app.use('/api/commands', commandRoute);

app.all('*', (req, res) => {
  return res
    .status(httpStatus.NOT_FOUND.code)
    .send(
      new Response(
        httpStatus.NOT_FOUND.code,
        httpStatus.NOT_FOUND.status,
        'Route not found',
        { error: 'Route not found' },
      ),
    );
});
app.listen(PORT, () =>
  logger.info(`Server running on: http://${ip.address()}:${PORT}`),
);
