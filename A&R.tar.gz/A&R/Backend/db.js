const sqlite = require("sqlite3").verbose();
const db = new sqlite.Database("./database.db", sqlite.OPEN_READWRITE, (err) => {
    if (err) {
        console.error(err.message);
    }
});

module.exports = db