const express = require('express');
const commandRoute = express.Router();

const {
  createCommand,
  getCommand,
  updateCommand,
  deleteCommand,
  getCommandById,
} = require('../controllers/commands/commandsController');

const {
  createGroup,
  getGroup,
  updateGroup,
  deleteGroup,
  getGroupById,
} = require('../controllers/commands/commandGroupController');

commandRoute.post('/commands/new', createCommand);
commandRoute.get('/commands', getCommand);
commandRoute.put('/commands/:id', updateCommand);
commandRoute.delete('/commands/:id', deleteCommand);
commandRoute.get('/commands/:id', getCommandById);

commandRoute.post('/groups/new', createGroup);
commandRoute.get('/groups', getGroup);
commandRoute.put('/groups/:id', updateGroup);
commandRoute.delete('/groups/:id', deleteGroup);
commandRoute.get('/groups/:id', getGroupById);

module.exports = commandRoute;
