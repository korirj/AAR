const express = require('express');
const reportRoute = express.Router();

const {
  createReport,
  getReport,
  updateReport,
  deleteReport,
  getReportById,
} = require('../controllers/report/reportController');

reportRoute.post('/reports/new', createReport);
reportRoute.get('/reports', getReport);
reportRoute.put('/reports/:id', updateReport);
reportRoute.delete('/reports/:id', deleteReport);
reportRoute.get('/reports/:id', getReportById);

module.exports = reportRoute;
