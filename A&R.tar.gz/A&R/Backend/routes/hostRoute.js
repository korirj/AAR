const express = require('express');
const hostRoute = express.Router();

const {
  createHost,
  getHost,
  updateHost,
  deleteHost,
  getHostById,
} = require('../controllers/hosts/hostController');
const {
  createGroup,
  getGroup,
  updateGroup,
  deleteGroup,
  getGroupById,
} = require('../controllers/hosts/hostGroupController');

const {
  createSite,
  getSite,
  updateSite,
  deleteSite,
  getSiteById,
} = require('../controllers/hosts/siteController');
const hostGroupController = require('../controllers/hosts/hostGroupController');
const siteController = require('../controllers/hosts/siteController');

hostRoute.post('/hosts/new', createHost);
hostRoute.get('/hosts', getHost);
hostRoute.put('/hosts/:id', updateHost);
hostRoute.delete('/hosts/:id', deleteHost);
hostRoute.get('/hosts/:id', getHostById);

hostRoute.post('/groups/new', createGroup);
hostRoute.get('/groups', getGroup);
hostRoute.put('/groups/:id', updateGroup);
hostRoute.delete('/groups/:id', deleteGroup);
hostRoute.get('/groups/:id', getGroupById);

hostRoute.post('/sites/new', createSite);
hostRoute.get('/sites', getSite);
hostRoute.put('/sites/:id', updateSite);
hostRoute.delete('/sites/:id', deleteSite);
hostRoute.get('/sites/:id', getSiteById);



module.exports = hostRoute;