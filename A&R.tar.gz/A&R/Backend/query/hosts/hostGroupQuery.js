const QUERY = {
  SELECT_GROUPS: `SELECT * FROM hostgroups ORDER BY created_at DESC LIMIT 100`,
  SELECT_GROUP: `SELECT * FROM hostgroups WHERE id = ?`,
  CREATE_GROUP: `INSERT INTO hostgroups(first_name, last_name, email,address,diagnosis, phone,image_url) VALUES(?,?,?,?,?,?,?)`,
  UPDATE_GROUP: `UPDATE hostgroups SET first_name = ?, last_name = ?, email = ?, address = ?, diagnosis = ?, phone = ?, image_url = ? WHERE id = ?`,
  DELETE_GROUP: `DELETE FROM hostgroups WHERE id = ?`,
};

module.exports = QUERY;
 