const QUERY = {
  SELECT_SITES: `SELECT * FROM hosts ORDER BY created_at DESC LIMIT 100`,
  SELECT_SITE: `SELECT * FROM hosts WHERE id = ?`,
  CREATE_SITE: `INSERT INTO hosts(first_name, last_name, email,address,diagnosis, phone,image_url) VALUES(?,?,?,?,?,?,?)`,
  UPDATE_SITE: `UPDATE hosts SET first_name = ?, last_name = ?, email = ?, address = ?, diagnosis = ?, phone = ?, image_url = ? WHERE id = ?`,
  DELETE_SITE: `DELETE FROM hosts WHERE id = ?`,
};

module.exports = QUERY;
