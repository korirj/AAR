const QUERY = {
  SELECT_HOSTS: `SELECT * FROM hosts ORDER BY created_at DESC LIMIT 100`,
  SELECT_HOST: `SELECT * FROM hosts WHERE id = ?`,
  CREATE_HOST: `INSERT INTO hosts(first_name, last_name, email,address,diagnosis, phone,image_url) VALUES(?,?,?,?,?,?,?)`,
  UPDATE_HOST: `UPDATE hosts SET first_name = ?, last_name = ?, email = ?, address = ?, diagnosis = ?, phone = ?, image_url = ? WHERE id = ?`,
  DELETE_HOST: `DELETE FROM hosts WHERE id = ?`,
};

module.exports = QUERY;
