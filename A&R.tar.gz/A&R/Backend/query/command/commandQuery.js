const QUERY = {
  SELECT_COMMANDS: `SELECT * FROM hosts ORDER BY created_at DESC LIMIT 100`,
  SELECT_COMMAND: `SELECT * FROM hosts WHERE id = ?`,
  CREATE_COMMAND: `INSERT INTO hosts(first_name, last_name, email,address,diagnosis, phone,image_url) VALUES(?,?,?,?,?,?,?)`,
  UPDATE_COMMAND: `UPDATE hosts SET first_name = ?, last_name = ?, email = ?, address = ?, diagnosis = ?, phone = ?, image_url = ? WHERE id = ?`,
  DELETE_COMMAND: `DELETE FROM hosts WHERE id = ?`,
};

module.exports = QUERY;
