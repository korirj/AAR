const QUERY = {
  SELECT_COMMANDGROUPS: `SELECT * FROM hostgroups ORDER BY created_at DESC LIMIT 100`,
  SELECT_COMMANDGROUP: `SELECT * FROM hostgroups WHERE id = ?`,
  CREATE_COMMANDGROUP: `INSERT INTO hostgroups(first_name, last_name, email,address,diagnosis, phone,image_url) VALUES(?,?,?,?,?,?,?)`,
  UPDATE_COMMANDGROUP: `UPDATE hostgroups SET first_name = ?, last_name = ?, email = ?, address = ?, diagnosis = ?, phone = ?, image_url = ? WHERE id = ?`,
  DELETE_COMMANDGROUP: `DELETE FROM hostgroups WHERE id = ?`,
};

module.exports = QUERY;
 