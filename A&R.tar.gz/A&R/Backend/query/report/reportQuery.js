const QUERY = {
  SELECT_REPORTS: `SELECT * FROM hosts ORDER BY created_at DESC LIMIT 100`,
  SELECT_REPORT: `SELECT * FROM hosts WHERE id = ?`,
  CREATE_REPORT: `INSERT INTO hosts(first_name, last_name, email,address,diagnosis, phone,image_url) VALUES(?,?,?,?,?,?,?)`,
  UPDATE_REPORT: `UPDATE hosts SET first_name = ?, last_name = ?, email = ?, address = ?, diagnosis = ?, phone = ?, image_url = ? WHERE id = ?`,
  DELETE_REPORT: `DELETE FROM hosts WHERE id = ?`,
};

module.exports = QUERY;
