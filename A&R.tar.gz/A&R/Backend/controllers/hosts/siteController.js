const db = require('../../db');
const Response = require('../../util/response');
const httpStatus = require('../../query/httpStatus');
const logger = require('../../util/logger');
const errorHandler = require('../../util/error');
const QUERY= require('../../query/hosts/sitesQueries');

const createSite = async (req, res, next) => {
  try {
    const { hostName, hostSite, hostIP, status } = req.body;
    const result = await db.run(QUERY.CREATE_SITE, [
      hostName,
      hostSite,
      hostIP,
      status,
    ]);
    if (result) {
      res
        .status(httpStatus.CREATED.code)
        .send(
          new Response(
            httpStatus.CREATED.code,
            httpStatus.CREATED.status,
            'Site created successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Site not created',
          ),
        );
    }
  } catch (error) {
    logger.error(error);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const getSite = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.SELECT_SITES, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Site fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Site not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const updateSite = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { hostName, hostSite, hostIP, status } = req.body;
    const result = await db.run(QUERY.UPDATE_SITE, [
      hostName,
      hostSite,
      hostIP,
      status,
      id,
    ]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Site updated successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Site not updated',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const deleteSite = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.DELETE_SITE, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Site deleted successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Site not deleted',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};
const getAllSites = async (req, res, next) => {
  try {
    const result = await db.run(QUERY.SELECT_SITES);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Sites fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Sites not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};
const getSiteById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.SELECT_SITES, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Site fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Site not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

module.exports = {
  createSite,
  getSite,
  updateSite,
  deleteSite,
  getAllSites,
  getSiteById,
};
