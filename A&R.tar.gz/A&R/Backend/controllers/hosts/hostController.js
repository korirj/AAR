const db = require('../../db');
const Response = require('../../util/response');
const httpStatus = require('../../query/httpStatus');
const logger = require('../../util/logger');
const errorHandler = require('../../util/error');
const QUERY= require('../../query/hosts/hostsQuery');

const createHost = async (req, res, next) => {
  try {
    const { hostName, hostGroup, hostIP, status } = req.body;
    const result = await db.run(QUERY.CREATE_HOST, [
      hostName,
      hostGroup,
      hostIP,
      status,
    ]);
    if (result) {
      res
        .status(httpStatus.CREATED.code)
        .send(
          new Response(
            httpStatus.CREATED.code,
            httpStatus.CREATED.status,
            'Host created successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Host not created',
          ),
        );
    }
  } catch (error) {
    logger.error(error);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const getHost = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.SELECT_HOSTS, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Host fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Host not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const updateHost = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { hostName, hostGroup, hostIP, status } = req.body;
    const result = await db.run(QUERY.UPDATE_HOST, [
      hostName,
      hostGroup,
      hostIP,
      status,
      id,
    ]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Host updated successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Host not updated',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const deleteHost = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.DELETE_HOST, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Host deleted successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Host not deleted',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};
const getAllHosts = async (req, res, next) => {
  try {
    const result = await db.run(QUERY.SELECT_HOSTS);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Hosts fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Hosts not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};
const getHostById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.SELECT_HOSTS, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Host fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Host not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

module.exports = {
  createHost,
  getAllHosts,
  getHost,
  updateHost,
  deleteHost,
  getHostById,
};
