const db = require('../../db');
const Response = require('../../util/response');
const httpStatus = require('../../query/httpStatus');
const logger = require('../../util/logger');
const errorHandler = require('../../util/error');
const QUERY= require('../../query/report/reportQuery');

const createReport = async (req, res, next) => {
  try {
    const { reportName, reportGroup, reportIP, status } = req.body;
    const result = await db.run(QUERY.CREATE_HOST, [
      reportName,
      reportGroup,
      reportIP,
      status,
    ]);
    if (result) {
      res
        .status(httpStatus.CREATED.code)
        .send(
          new Response(
            httpStatus.CREATED.code,
            httpStatus.CREATED.status,
            'Report created successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Report not created',
          ),
        );
    }
  } catch (error) {
    logger.error(error);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const getReport = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.SELECT_HOSTS, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Report fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Report not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const updateReport = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { reportName, reportGroup, reportIP, status } = req.body;
    const result = await db.run(QUERY.UPDATE_HOST, [
      reportName,
      reportGroup,
      reportIP,
      status,
      id,
    ]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Report updated successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Report not updated',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const deleteReport = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.DELETE_HOST, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Report deleted successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Report not deleted',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};
const getAllReports = async (req, res, next) => {
  try {
    const result = await db.run(QUERY.SELECT_HOSTS);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Reports fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Reports not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};
const getReportById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.SELECT_HOSTS, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Report fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Report not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

module.exports = {
  createReport,
  getAllReports,
  getReport,
  updateReport,
  deleteReport,
  getReportById,
};
