const db = require('../../db');
const httpStatus = require('../../query/httpStatus');
const logger = require('../../util/logger');
const errorHandler = require('../../util/error');
const QUERY= require('../../query/command/commandGroupQuery');

const createGroup = async (req, res, next) => {
  try {
    const { hostName, hostGroup, hostIP, status } = req.body;
    const result = await db.run(QUERY.CREATE_HOST, [
      hostName,
      hostGroup,
      hostIP,
      status,
    ]);
    if (result) {
      res
        .status(httpStatus.CREATED.code)
        .send(
          new Response(
            httpStatus.CREATED.code,
            httpStatus.CREATED.status,
            'Group created successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Group not created',
          ),
        );
    }
  } catch (error) {
    logger.error(error);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const getGroup = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.SELECT_HOSTS, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Group fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Group not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const updateGroup = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { hostName, hostGroup, hostIP, status } = req.body;
    const result = await db.run(QUERY.UPDATE_HOST, [
      hostName,
      hostGroup,
      hostIP,
      status,
      id,
    ]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Group updated successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Group not updated',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const deleteGroup = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.DELETE_HOST, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Group deleted successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Group not deleted',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};
const getAllGroups = async (req, res, next) => {
  try {
    const result = await db.run(QUERY.SELECT_HOSTS);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Groups fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Groups not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};
const getGroupById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.SELECT_HOSTS, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Group fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Group not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

module.exports = {
  createGroup,
  getGroup,
  updateGroup,
  deleteGroup,
  getAllGroups,
  getGroupById,
};
