const httpStatus = require('../../query/httpStatus');
const logger = require('../../util/logger');
const errorHandler = require('../../util/error');
const QUERY= require('../../query/command/commandQuery');

const createCommand = async (req, res, next) => {
  try {
    const { commandName, commandGroup, commandIP, status } = req.body;
    const result = await db.run(QUERY.CREATE_HOST, [
      commandName,
      commandGroup,
      commandIP,
      status,
    ]);
    if (result) {
      res
        .status(httpStatus.CREATED.code)
        .send(
          new Response(
            httpStatus.CREATED.code,
            httpStatus.CREATED.status,
            'Command created successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Command not created',
          ),
        );
    }
  } catch (error) {
    logger.error(error);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const getCommand = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.SELECT_HOSTS, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Command fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Command not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const updateCommand = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { commandName, commandGroup, commandIP, status } = req.body;
    const result = await db.run(QUERY.UPDATE_HOST, [
      commandName,
      commandGroup,
      commandIP,
      status,
      id,
    ]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Command updated successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Command not updated',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

const deleteCommand = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.DELETE_HOST, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Command deleted successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Command not deleted',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};
const getAllCommands = async (req, res, next) => {
  try {
    const result = await db.run(QUERY.SELECT_HOSTS);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Commands fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Commands not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};
const getCommandById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.run(QUERY.SELECT_HOSTS, [id]);
    if (result) {
      res
        .status(httpStatus.OK.code)
        .send(
          new Response(
            httpStatus.OK.code,
            httpStatus.OK.status,
            'Command fetched successfully',
            result,
          ),
        );
    } else {
      res
        .status(httpStatus.BAD_REQUEST.code)
        .send(
          new Response(
            httpStatus.BAD_REQUEST.code,
            httpStatus.BAD_REQUEST.status,
            'Command not fetched',
          ),
        );
    }
  } catch (error) {
    logger.error(error.message);
    next(errorHandler(httpStatus.INTERNAL_SERVER_ERROR.code, error.message));
  }
};

module.exports = {
  createCommand,
  getAllCommands,
  getCommand,
  updateCommand,
  deleteCommand,
  getCommandById,
};
