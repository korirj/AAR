CREATE DATABASE IF NOT EXISTS reportsdb;
USE reportsdb;

-- Create the Site Table
CREATE TABLE IF NOT EXISTS sites (
    site_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    status TEXT,
    hostGroups INTEGER
);

-- Create the HostGroup Table
CREATE TABLE IF NOT EXISTS host_groups (
    group_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    username TEXT,
    password TEXT,
    site_id INTEGER,
    status TEXT,
    FOREIGN KEY (site_id) REFERENCES sites (site_id)
);

-- Create the Host Table
CREATE TABLE IF NOT EXISTS hosts (
    host_id INTEGER PRIMARY KEY,
    hostname TEXT NOT NULL,
    hostGroup INTEGER, -- Reference host_groups.group_id
    hostIP TEXT,
    status TEXT,
    FOREIGN KEY (hostGroup) REFERENCES host_groups (group_id)
);

-- Create the Command Table
CREATE TABLE IF NOT EXISTS commands (
    command_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    command TEXT NOT NULL,
    description TEXT,
    status TEXT
);

-- Create the CommandGroup Table
CREATE TABLE IF NOT EXISTS command_groups (
    group_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    status TEXT,
    description TEXT
);

-- Create the CommandGroup_Commands Table
CREATE TABLE IF NOT EXISTS command_group_commands (
    group_id INTEGER,
    command_id INTEGER,
    FOREIGN KEY (group_id) REFERENCES command_groups (group_id),
    FOREIGN KEY (command_id) REFERENCES commands (command_id)
);

-- Create the Reports Table
CREATE TABLE IF NOT EXISTS reports (
    report_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    status TEXT,
    commandMap TEXT -- Store the JSON data here
);

-- Create the Report_Commands Table
CREATE TABLE IF NOT EXISTS report_commands (
    report_id INTEGER,
    command_id INTEGER,
    FOREIGN KEY (report_id) REFERENCES reports (report_id),
    FOREIGN KEY (command_id) REFERENCES commands (command_id)
);

